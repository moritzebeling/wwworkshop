alert('Welcome!');
